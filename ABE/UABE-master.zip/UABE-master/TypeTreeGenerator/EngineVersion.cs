namespace TypeTreeGenerator
{
    public struct EngineVersion
    {
        public uint year;
        public uint release;
        public EngineVersion(uint year, uint release) { this.year = year; this.release = release; }
    }
}
