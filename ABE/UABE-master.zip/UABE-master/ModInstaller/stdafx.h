#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <tchar.h>
#include <stdio.h>
#include <Windows.h>
#include <WindowsX.h>
#include <CommCtrl.h>

