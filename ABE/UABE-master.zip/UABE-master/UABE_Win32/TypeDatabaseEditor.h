#pragma once

void OpenTypeDatabaseEditor(HINSTANCE hInstance, HWND hParent);