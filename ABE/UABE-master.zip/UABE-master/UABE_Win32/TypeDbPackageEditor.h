#pragma once

void OpenTypeDbPackageEditor(HINSTANCE hInstance, HWND hParent);