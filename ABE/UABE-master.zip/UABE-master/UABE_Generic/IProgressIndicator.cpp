#include "IProgressIndicator.h"

IProgressIndicator::IProgressIndicator() {}
IProgressIndicator::~IProgressIndicator() {}
