#include "PluginManager.h"

IOptionProvider::~IOptionProvider() {}
IPluginDesc::~IPluginDesc() {}
IOptionRunner::~IOptionRunner() {}

IAssetOptionProviderGeneric::IAssetOptionProviderGeneric() {}
