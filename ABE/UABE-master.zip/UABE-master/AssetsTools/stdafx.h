#pragma once

//#define WIN32_LEAN_AND_MEAN
//#ifndef _UNICODE
//#define _UNICODE
//#endif
//#define NOMINMAX
//
//#include <windows.h>

#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

typedef uint64_t QWORD;
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
