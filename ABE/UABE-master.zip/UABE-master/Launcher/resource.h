//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AssetBundleExtractor.rc
//

#define IDS_APP_TITLE                   103
#define IDI_ASSETBUNDLEEXTRACTOR        107
#define IDC_ASSETBUNDLEEXTRACTOR        109
