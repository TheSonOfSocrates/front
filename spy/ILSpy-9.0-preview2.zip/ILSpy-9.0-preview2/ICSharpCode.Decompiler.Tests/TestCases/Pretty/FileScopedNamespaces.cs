﻿namespace ICSharpCode.Decompiler.Tests.TestCases.Pretty;

internal delegate void DelegateInFileScopedNamespace();

internal class FileScopedNamespaces
{

}

