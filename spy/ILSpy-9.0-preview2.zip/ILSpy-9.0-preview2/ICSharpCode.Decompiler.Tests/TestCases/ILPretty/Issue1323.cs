﻿public enum Enum0
{
	// error: enumerator has no value
	const_0,
	// error: enumerator has no value
	const_1,
	// error: enumerator has no value
	const_2,
	// error: enumerator has no value
	const_3
}