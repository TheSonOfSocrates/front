﻿namespace ICSharpCode.Decompiler.Tests.TestCases.ILPretty
{
	internal class ConstantBlobs
	{
		public static void Float_Int32(float f1 = 0f, float f2 = -1f, float f3 = int.MaxValue, float f4 = int.MinValue)
		{
		}
	}
}
