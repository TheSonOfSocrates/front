﻿## About

ICSharpCode.BamlDecompiler is the library used by the BAML Addin in ILSpy to decompile BAML to XAML.
