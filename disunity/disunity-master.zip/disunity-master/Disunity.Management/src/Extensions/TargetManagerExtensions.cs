using System.Threading.Tasks;

using Disunity.Core.Archives;
using Disunity.Management.Models;


namespace Disunity.Management.Extensions {

    public static class TargetManagerExtensions {

        

    }

}