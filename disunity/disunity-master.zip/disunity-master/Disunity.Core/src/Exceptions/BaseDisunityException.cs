using System;


namespace Disunity.Core.Exceptions {

    public class BaseDisunityException : Exception { }

}