namespace Disunity.Core.Exceptions {

    public class ManifestParseException : BaseDisunityException {

        

    }

}