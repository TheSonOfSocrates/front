namespace Disunity.Store.Entities {

    public enum UserRoles {

        Admin,
        User

    }

}