namespace Disunity.Store.Util {

    public static class HelloWorld {

        public static string Greet(string name = "World") {
            return $"Hello {name}!";
        }

    }

}