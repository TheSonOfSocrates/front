namespace Disunity.Store.Policies {

    public enum Operation {

        Create,
        Read,
        Update,
        Delete,
        ManageMembers,
        ManageMemberRoles

    }

}