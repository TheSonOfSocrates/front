export default interface IErrorReport {
    ReportException(exception: any): void;
}