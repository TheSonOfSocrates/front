﻿using System;


namespace Disunity.Management.Startup {

    class Program {

        public static void Main(string[] args) {
            
        }

    }

}