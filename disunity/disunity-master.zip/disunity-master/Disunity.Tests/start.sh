#!/usr/bin/env bash
export FrameworkPathOverride=/usr/lib/mono/4.7.1-api/

dotnet test
